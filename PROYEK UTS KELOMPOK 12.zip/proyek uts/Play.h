#ifndef PLAY_H
#define PLAY_H
#define SAIR 99

int easy();
int medium();
int hard();
int bonus();
char name[20];

#endif
