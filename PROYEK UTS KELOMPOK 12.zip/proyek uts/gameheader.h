#ifndef GAME_HEADER
#define GAME_HEADER

int menu, how, input, lead, lead2, lead3, lead4;
int game(), leaderboard(), petunjuk(), handling(), game1(), game2(), game3(), easy(), normal(), hard();


#endif
